# Security Policy

## Supported Versions

We support only versions that are ticked.

| Version | Supported          |
| ------- | ------------------ |
| 1.8.0   | :white_check_mark: |
| <=1.7.x | :x:                |

## Reporting a Vulnerability

To report a vulnerability, you have to join [our Discord server](https://pterodactyl-resources/discord) and create a ticket. Explain your situation there.

Don't make an issue or tell it in public in Discord or somewhere else.
